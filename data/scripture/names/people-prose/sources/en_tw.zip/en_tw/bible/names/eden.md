# Eden, garden of Eden

## Definition:

In ancient times, Eden was a region that had a garden where God placed the first man and woman to live.

* The garden where Adam and Eve lived was only part of Eden.
* The exact location of the region of Eden is not certain, but the Tigris and Euphrates Rivers were flowing through it.
* The word “Eden” comes from a Hebrew word meaning to “take great delight in.”

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Adam](../names/adam.md), [Euphrates River](../names/euphrates.md), [Eve](../names/eve.md))

## Bible References:

* [Ezekiel 28:11-13](rc://en/tn/help/ezk/28/11)
* [Genesis 2:7-8](rc://en/tn/help/gen/02/07)
* [Genesis 2:10](rc://en/tn/help/gen/02/10)
* [Genesis 2:15](rc://en/tn/help/gen/02/15)
* [Genesis 4:16-17](rc://en/tn/help/gen/04/16)
* [Joel 2:3](rc://en/tn/help/jol/02/3)

## Word Data:

* Strong’s: H5729, H5731
