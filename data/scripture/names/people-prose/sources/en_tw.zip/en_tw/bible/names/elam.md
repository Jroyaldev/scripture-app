# Elam, Elamites

## Definition:

Elam was a son of Shem and a grandson of Noah.

* The descendants of Elam were called “Elamites,” and they lived in a region that was also called “Elam.”
* The region of Elam was located southeast of the Tigris River in what is now western Iran.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Noah](../names/noah.md), [Shem](../names/shem.md))

## Bible References:

* [1 Chronicles 1:17-19](rc://en/tn/help/1ch/01/17)
* [Acts 2:9](rc://en/tn/help/act/02/09)
* [Ezra 8:4-7](rc://en/tn/help/ezr/08/04)
* [Isaiah 22:6](rc://en/tn/help/isa/22/06)

## Word Data:

* Strong’s: H5867, H5962, G16390
