# Judea, Judah

## Definition:

The term “Judea” refers to an area of land in ancient Israel. It is sometimes used in a narrow sense and other times in a broad sense.

* Sometimes “Judea” is used in a narrow sense to refer only to the province located in the southern part of ancient Israel just west of the Dead Sea. Some translations call this province “Judah.”
* Other times “Judea” has a broad sense and refers to all the provinces of ancient Israel, including Galilee, Samaria, Perea, Idumea and Judea (Judah).
* If translators want to make the distinction clear, the broad sense of Judea could be translated as “Judea Country” and the narrow sense could be translated as “Judea Province,” or “Judah Province” since this is the part of ancient Israel where the tribe of Judah had originally lived.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Galilee](../names/galilee.md), [Edom](../names/edom.md), [Judah](../names/judah.md), [Judah](../names/kingdomofjudah.md), [Samaria](../names/samaria.md))

## Bible References:

* [1 Thessalonians 2:14](rc://en/tn/help/1th/02/14)
* [Acts 2:9](rc://en/tn/help/act/02/09)
* [Acts 9:32](rc://en/tn/help/act/09/32)
* [Acts 12:19](rc://en/tn/help/act/12/19)
* [John 3:22-24](rc://en/tn/help/jhn/03/22)
* [Luke 1:5](rc://en/tn/help/luk/01/05)
* [Luke 4:44](rc://en/tn/help/luk/04/44)
* [Luke 5:17](rc://en/tn/help/luk/05/17)
* [Mark 10:1-4](rc://en/tn/help/mrk/10/01)
* [Matthew 2:1](rc://en/tn/help/mat/02/01)
* [Matthew 2:5](rc://en/tn/help/mat/02/05)
* [Matthew 2:22-23](rc://en/tn/help/mat/02/22)
* [Matthew 3:1-3](rc://en/tn/help/mat/03/01)
* [Matthew 19:1](rc://en/tn/help/mat/19/01)

## Word Data:

* Strong’s: G24530
