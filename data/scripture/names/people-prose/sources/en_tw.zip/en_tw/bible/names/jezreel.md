# Jezreel, Jezreelite

## Definition:

Jezreel was an important Israelite city in the territory of the Issachar tribe, located southwest of the Salt Sea. The name means "God scatters." 

* The city of Jezreel is one of the western points in the Plain of Megiddo, which is also called the “Valley of Jezreel.”
* Several kings of Israel had their palaces in the city of Jezreel.
* Naboth’s vineyard was located near King Ahab’s palace in Jezreel. The prophet Elijah prophesied against Ahab there.
* Ahab’s evil wife Jezebel was killed in Jezreel.
* Jehu slaughtered Joram king of Israel, Ahaziah king of Judah, their families, and their supporters at Jezreel.
* Many other significant events happened in this city, including several battles.

(See also: [Ahab](../names/ahab.md), [Elijah](../names/elijah.md), [Issachar](../names/issachar.md), [Jezebel](../names/jezebel.md), [palace](../other/palace.md), [Salt Sea](../names/saltsea.md))

## Bible References:

* [1 Kings 4:12](rc://en/tn/help/1ki/04/12)
* [1 Samuel 25:43-44](rc://en/tn/help/1sa/25/43)
* [2 Kings 8:28-29](rc://en/tn/help/2ki/08/28)
* [2 Kings 9:30](rc://en/tn/help/2ki/09/30)
* [2 Samuel 2:1-3](rc://en/tn/help/2sa/02/01)
* [Judges 6:33](rc://en/tn/help/jdg/06/33)
* [Hosea 1:4](rc://en/tn/help/hos/01/04)

## Word Data:

* Strong’s: H3157, H3158, H3159
