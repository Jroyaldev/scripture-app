# temple, house, house of God

## Definition:

A temple is a building dedicated to the worship of a specific diety where that diety was thought to dwell. Nations around Israel had temples dedicated to their various gods. The temple in Israel was a building surrounded by walled courtyards where the Israelites came to pray and to offer sacrifices to God. It was located on Mount Moriah in the city of Jerusalem.

* Often the term “temple” referred to the whole temple complex, including the courtyards that surrounded the main building. Sometimes it referred only to the building.
* The temple building had two rooms, the Holy Place and the Most Holy Place.
* God referred to the temple as his dwelling place.
* King Solomon built the first temple during his reign. It was supposed to be the permanent place of worship in Jerusalem.


## Translation Suggestions:

* Usually when the text says that people were “in the temple,” it is referring to the courtyards outside the building. This could be translated as “in the temple courtyards” or “in the temple complex.”
* Where it refers specifically to the building itself, some translations translate “temple” as “temple building,” to make it the reference clear.
* Ways to translate “temple” could include, “God’s holy house” or “sacred worship place.”
* Often in the Bible, the temple is referred to as “the house of Yahweh” or “the house of God.”

(See also: [sacrifice](../other/sacrifice.md), [Solomon](../names/solomon.md), [Babylon](../names/babylon.md), [Holy Spirit](../kt/holyspirit.md), [tabernacle](../kt/tabernacle.md), [courtyard](../other/courtyard.md), [Zion](../kt/zion.md), [house](../other/house.md))

## Bible References:

* [Acts 3:2](rc://en/tn/help/act/03/02)
* [Acts 3:8](rc://en/tn/help/act/03/08)
* [Ezekiel 45:18-20](rc://en/tn/help/ezk/45/18)
* [Luke 19:46](rc://en/tn/help/luk/19/46)
* [Nehemiah 10:28](rc://en/tn/help/neh/10/28)
* [Psalm 79:1-3](rc://en/tn/help/psa/079/001)

## Examples from the Bible stories:

* __[17:6](rc://en/tn/help/obs/17/06)__ David wanted to build a __temple__ where all the Israelites could worship God and offer him sacrifices.
* __[18:2](rc://en/tn/help/obs/18/02)__ In Jerusalem, Solomon built the __Temple__ for which his father David had planned and gathered materials. Instead of at the Tent of Meeting, people now worshiped God and offered sacrifices to him at the __Temple__. God came and was present in the __Temple__, and he lived there with his people.
* __[20:7](rc://en/tn/help/obs/20/07)__ They (Babylonians) captured the city of Jerusalem, destroyed the __Temple__, and took away all the treasures.
* __[20:13](rc://en/tn/help/obs/20/13)__ When the people arrived in Jerusalem, they rebuilt the __Temple__ and the wall around the city.
* __[25:4](rc://en/tn/help/obs/25/04)__ Then Satan took Jesus to the highest point on the __Temple__ and said, “If you are the Son of God, throw yourself down, for it is written, ‘God will command his angels to carry you so your foot does not hit a stone.’”
* __[40:7](rc://en/tn/help/obs/40/07)__ When he died, there was an earthquake and the large curtain that separated the people from the presence of God in the __Temple__ was torn in two, from the top to the bottom.

## Word Data:

* Strong’s: H1004, H1964, H1965, G14930, G24110, G34850
